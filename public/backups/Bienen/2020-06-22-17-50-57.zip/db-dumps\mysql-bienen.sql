
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_vencimiento` date NOT NULL,
  `duracion_pro` int(11) DEFAULT NULL,
  `cant_personas` int(11) NOT NULL,
  `duracion_real` int(11) DEFAULT NULL,
  `dia` enum('Mié','Jue','Vie','Sáb','Dom','Lun','Mar') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('PM01','PM02','PM03','PM04') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PM01',
  `realizada` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'No',
  `observacion1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_planificacion` bigint(20) unsigned NOT NULL,
  `id_area` bigint(20) unsigned NOT NULL,
  `id_departamento` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_id_planificacion_foreign` (`id_planificacion`),
  KEY `actividades_id_area_foreign` (`id_area`),
  KEY `actividades_id_departamento_foreign` (`id_departamento`),
  CONSTRAINT `actividades_id_area_foreign` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_id_departamento_foreign` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_id_planificacion_foreign` FOREIGN KEY (`id_planificacion`) REFERENCES `planificacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
INSERT INTO `actividades` VALUES (18,'Actividad12',NULL,'2020-04-15',NULL,2,NULL,'Mié','PM03','No',NULL,NULL,31,1,2,'2020-04-13 18:36:14','2020-04-13 18:36:14'),(19,'Actividad12',NULL,'2020-04-29',NULL,2,NULL,'Mié','PM03','No',NULL,NULL,35,1,2,'2020-04-13 18:36:14','2020-04-13 18:36:14'),(20,'eeeqqqqqq',NULL,'2020-04-15',NULL,2,NULL,'Mié','PM03','No',NULL,NULL,31,1,2,'2020-04-16 20:55:01','2020-04-16 20:55:01'),(21,'yyyyy',NULL,'2020-04-15',NULL,2,NULL,'Mié','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:40','2020-04-16 20:55:40'),(22,'yyyyy',NULL,'2020-04-16',NULL,2,NULL,'Jue','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:40','2020-04-16 20:55:40'),(23,'yyyyy',NULL,'2020-04-17',NULL,2,NULL,'Vie','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:40','2020-04-16 20:55:40'),(24,'yyyyy',NULL,'2020-04-18',NULL,2,NULL,'Sáb','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:40','2020-04-16 20:55:40'),(25,'yyyyy',NULL,'2020-04-19',NULL,2,NULL,'Dom','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:40','2020-04-16 20:55:40'),(26,'yyyyy',NULL,'2020-04-20',NULL,2,NULL,'Lun','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(27,'yyyyy',NULL,'2020-04-21',NULL,2,NULL,'Mar','PM03','No',NULL,NULL,31,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(28,'yyyyy',NULL,'2020-04-22',NULL,2,NULL,'Mié','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(29,'yyyyy',NULL,'2020-04-23',NULL,2,NULL,'Jue','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(30,'yyyyy',NULL,'2020-04-24',NULL,2,NULL,'Vie','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(31,'yyyyy',NULL,'2020-04-25',NULL,2,NULL,'Sáb','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(32,'yyyyy',NULL,'2020-04-26',NULL,2,NULL,'Dom','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(33,'yyyyy',NULL,'2020-04-27',NULL,2,NULL,'Lun','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(34,'yyyyy',NULL,'2020-04-28',NULL,2,NULL,'Mar','PM03','No',NULL,NULL,33,2,2,'2020-04-16 20:55:41','2020-04-16 20:55:41'),(35,'222',NULL,'2020-04-15',NULL,3,NULL,'Mié','PM04','No',NULL,NULL,31,1,1,'2020-04-16 21:02:59','2020-04-16 21:02:59'),(74,'actividad de prueba img files',NULL,'2020-05-06',67,1,NULL,'Mié','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:07:59','2020-05-13 00:07:59'),(75,'actividad de prueba img files',NULL,'2020-05-07',67,1,NULL,'Jue','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:00','2020-05-13 00:08:00'),(76,'actividad de prueba img files',NULL,'2020-05-08',67,1,NULL,'Vie','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:00','2020-05-13 00:08:00'),(77,'actividad de prueba img files',NULL,'2020-05-09',67,1,NULL,'Sáb','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:00','2020-05-13 00:08:00'),(78,'actividad de prueba img files',NULL,'2020-05-10',67,1,NULL,'Dom','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:01','2020-05-13 00:08:01'),(79,'actividad de prueba img files',NULL,'2020-05-11',67,1,NULL,'Lun','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:02','2020-05-13 00:08:02'),(80,'actividad de prueba img files',NULL,'2020-05-12',67,1,NULL,'Mar','PM01','No',NULL,NULL,37,1,1,'2020-05-13 00:08:02','2020-05-13 00:08:02'),(81,'actividad de prueba imgs/files',NULL,'2020-05-06',33,1,NULL,'Mié','PM02','No',NULL,NULL,37,1,1,'2020-05-13 00:09:41','2020-05-13 00:09:41'),(82,'actividad de prueba IF',NULL,'2020-05-06',11,1,NULL,'Mié','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:25:59','2020-05-13 00:25:59'),(83,'actividad de prueba IF',NULL,'2020-05-07',11,1,NULL,'Jue','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:00','2020-05-13 00:26:00'),(84,'actividad de prueba IF',NULL,'2020-05-08',11,1,NULL,'Vie','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:02','2020-05-13 00:26:02'),(85,'actividad de prueba IF',NULL,'2020-05-09',11,1,NULL,'Sáb','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:02','2020-05-13 00:26:02'),(86,'actividad de prueba IF',NULL,'2020-05-10',11,1,NULL,'Dom','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:02','2020-05-13 00:26:02'),(87,'actividad de prueba IF',NULL,'2020-05-11',11,1,NULL,'Lun','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:02','2020-05-13 00:26:02'),(88,'actividad de prueba IF',NULL,'2020-05-12',11,1,NULL,'Mar','PM03','No',NULL,NULL,37,1,2,'2020-05-13 00:26:02','2020-05-13 00:26:02'),(89,'actividad de prueba IOf',NULL,'2020-05-06',11,1,NULL,'Mié','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:33','2020-05-13 00:27:33'),(90,'actividad de prueba IOf',NULL,'2020-05-07',11,1,NULL,'Jue','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:33','2020-05-13 00:27:33'),(91,'actividad de prueba IOf',NULL,'2020-05-08',11,1,NULL,'Vie','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:33','2020-05-13 00:27:33'),(92,'actividad de prueba IOf',NULL,'2020-05-09',11,1,NULL,'Sáb','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:33','2020-05-13 00:27:33'),(93,'actividad de prueba IOf',NULL,'2020-05-10',11,1,NULL,'Dom','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:34','2020-05-13 00:27:34'),(94,'actividad de prueba IOf',NULL,'2020-05-11',11,1,NULL,'Lun','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:34','2020-05-13 00:27:34'),(95,'actividad de prueba IOf',NULL,'2020-05-12',11,1,NULL,'Mar','PM04','No',NULL,NULL,37,1,1,'2020-05-13 00:27:34','2020-05-13 00:27:34'),(96,'actividad de prueba img',NULL,'2020-05-13',NULL,1,NULL,'Mié','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:10','2020-05-18 16:23:10'),(97,'actividad de prueba img',NULL,'2020-05-14',NULL,1,NULL,'Jue','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:10','2020-05-18 16:23:10'),(98,'actividad de prueba img',NULL,'2020-05-15',NULL,1,NULL,'Vie','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:10','2020-05-18 16:23:10'),(99,'actividad de prueba img',NULL,'2020-05-16',NULL,1,NULL,'Sáb','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:10','2020-05-18 16:23:10'),(100,'actividad de prueba img',NULL,'2020-05-17',NULL,1,NULL,'Dom','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:11','2020-05-18 16:23:11'),(101,'actividad de prueba img',NULL,'2020-05-18',NULL,1,NULL,'Lun','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:12','2020-05-18 16:23:12'),(102,'actividad de prueba img',NULL,'2020-05-19',NULL,1,NULL,'Mar','PM03','No',NULL,NULL,39,1,2,'2020-05-18 16:23:12','2020-05-18 16:23:12');
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_adjuntos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actv_proceso` bigint(20) unsigned NOT NULL,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('img','file') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_adjuntos_id_usuario_foreign` (`id_usuario`),
  KEY `actividades_adjuntos_id_actv_proceso_foreign` (`id_actv_proceso`),
  CONSTRAINT `actividades_adjuntos_id_actv_proceso_foreign` FOREIGN KEY (`id_actv_proceso`) REFERENCES `actividades_proceso` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_adjuntos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_adjuntos` WRITE;
/*!40000 ALTER TABLE `actividades_adjuntos` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_adjuntos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_comentarios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actv_proceso` bigint(20) unsigned NOT NULL,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_comentarios_id_usuario_foreign` (`id_usuario`),
  KEY `actividades_comentarios_id_actv_proceso_foreign` (`id_actv_proceso`),
  CONSTRAINT `actividades_comentarios_id_actv_proceso_foreign` FOREIGN KEY (`id_actv_proceso`) REFERENCES `actividades_proceso` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_comentarios_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_comentarios` WRITE;
/*!40000 ALTER TABLE `actividades_comentarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_comentarios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_has_archivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_has_archivos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('img','file') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_has_archivos_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_has_archivos_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_has_archivos` WRITE;
/*!40000 ALTER TABLE `actividades_has_archivos` DISABLE KEYS */;
INSERT INTO `actividades_has_archivos` VALUES (11,74,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:07:59','2020-05-13 00:07:59'),(12,74,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:07:59','2020-05-13 00:07:59'),(13,74,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:07:59','2020-05-13 00:07:59'),(14,74,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:07:59','2020-05-13 00:07:59'),(15,75,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(16,75,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(17,75,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(18,75,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(19,76,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(20,76,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(21,76,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(22,76,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(23,77,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(24,77,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:00','2020-05-13 00:08:00'),(25,77,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(26,77,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:00','2020-05-13 00:08:00'),(27,78,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:01','2020-05-13 00:08:01'),(28,78,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:01','2020-05-13 00:08:01'),(29,78,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:01','2020-05-13 00:08:01'),(30,78,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:01','2020-05-13 00:08:01'),(31,79,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:02','2020-05-13 00:08:02'),(32,79,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:02','2020-05-13 00:08:02'),(33,79,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:02','2020-05-13 00:08:02'),(34,79,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:02','2020-05-13 00:08:02'),(35,80,'O5G4_Curriculum - César Characo.docx','files_actividades/O5G4_Curriculum - César Characo.docx','file','2020-05-13 00:08:02','2020-05-13 00:08:02'),(36,80,'QPLN_Curriculum - César Characo.pdf','files_actividades/QPLN_Curriculum - César Characo.pdf','file','2020-05-13 00:08:02','2020-05-13 00:08:02'),(37,80,'QPLN_Lighthouse.jpg','imgs_actividades/QPLN_Lighthouse.jpg','img','2020-05-13 00:08:02','2020-05-13 00:08:02'),(38,80,'QPLN_Koala.jpg','imgs_actividades/QPLN_Koala.jpg','img','2020-05-13 00:08:02','2020-05-13 00:08:02'),(39,81,'OQNS_cedulapiki.pdf','files_actividades/OQNS_cedulapiki.pdf','file','2020-05-13 00:09:41','2020-05-13 00:09:41'),(40,81,'OQNS_Jellyfish.jpg','imgs_actividades/OQNS_Jellyfish.jpg','img','2020-05-13 00:09:41','2020-05-13 00:09:41'),(41,82,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:00','2020-05-13 00:26:00'),(42,82,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:00','2020-05-13 00:26:00'),(43,83,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:01','2020-05-13 00:26:01'),(44,83,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:01','2020-05-13 00:26:01'),(45,84,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:02','2020-05-13 00:26:02'),(46,84,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:02','2020-05-13 00:26:02'),(47,85,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:02','2020-05-13 00:26:02'),(48,85,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:02','2020-05-13 00:26:02'),(49,86,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:02','2020-05-13 00:26:02'),(50,86,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:02','2020-05-13 00:26:02'),(51,87,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:02','2020-05-13 00:26:02'),(52,87,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:02','2020-05-13 00:26:02'),(53,88,'06I6_cedulapiki.pdf','files_actividades/06I6_cedulapiki.pdf','file','2020-05-13 00:26:02','2020-05-13 00:26:02'),(54,88,'06I6_Tulips.jpg','imgs_actividades/06I6_Tulips.jpg','img','2020-05-13 00:26:02','2020-05-13 00:26:02'),(55,89,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:33','2020-05-13 00:27:33'),(56,89,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:33','2020-05-13 00:27:33'),(57,90,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:33','2020-05-13 00:27:33'),(58,90,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:33','2020-05-13 00:27:33'),(59,91,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:33','2020-05-13 00:27:33'),(60,91,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:33','2020-05-13 00:27:33'),(61,92,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:33','2020-05-13 00:27:33'),(62,92,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:34','2020-05-13 00:27:34'),(63,93,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:34','2020-05-13 00:27:34'),(64,93,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:34','2020-05-13 00:27:34'),(65,94,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:34','2020-05-13 00:27:34'),(66,94,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:34','2020-05-13 00:27:34'),(67,95,'FCIU_cedulapiki.pdf','files_actividades/FCIU_cedulapiki.pdf','file','2020-05-13 00:27:34','2020-05-13 00:27:34'),(68,95,'FCIU_Tulips.jpg','imgs_actividades/FCIU_Tulips.jpg','img','2020-05-13 00:27:34','2020-05-13 00:27:34'),(69,96,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:10','2020-05-18 16:23:10'),(70,96,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:10','2020-05-18 16:23:10'),(71,97,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:10','2020-05-18 16:23:10'),(72,97,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:10','2020-05-18 16:23:10'),(73,98,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:10','2020-05-18 16:23:10'),(74,98,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:10','2020-05-18 16:23:10'),(75,99,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:10','2020-05-18 16:23:10'),(76,99,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:10','2020-05-18 16:23:10'),(77,100,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:11','2020-05-18 16:23:11'),(78,100,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:11','2020-05-18 16:23:11'),(79,101,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:12','2020-05-18 16:23:12'),(80,101,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:12','2020-05-18 16:23:12'),(81,102,'ZLRY_Curriculum - César Characo.pdf','files_actividades/ZLRY_Curriculum - César Characo.pdf','file','2020-05-18 16:23:12','2020-05-18 16:23:12'),(82,102,'ZLRY_Desert.jpg','imgs_actividades/ZLRY_Desert.jpg','img','2020-05-18 16:23:12','2020-05-18 16:23:12');
/*!40000 ALTER TABLE `actividades_has_archivos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_proceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_proceso` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `hora_inicio` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_finalizada` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Iniciada','Finalizada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Iniciada',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_proceso_id_empleado_foreign` (`id_empleado`),
  KEY `actividades_proceso_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_proceso_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_proceso_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_proceso` WRITE;
/*!40000 ALTER TABLE `actividades_proceso` DISABLE KEYS */;
INSERT INTO `actividades_proceso` VALUES (4,18,2,'\'2020-04-16 16:53:32\'',NULL,'Iniciada',NULL,NULL),(5,20,2,'\'2020-04-16 16:55:01\'',NULL,'Iniciada',NULL,NULL),(6,21,2,'\'2020-04-16 16:55:40\'',NULL,'Iniciada',NULL,NULL),(7,22,2,'\'2020-04-16 16:55:40\'',NULL,'Iniciada',NULL,NULL),(8,23,2,'\'2020-04-16 16:55:40\'',NULL,'Iniciada',NULL,NULL),(9,24,2,'\'2020-04-16 16:55:40\'',NULL,'Iniciada',NULL,NULL),(10,25,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(11,26,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(12,27,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(13,28,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(14,29,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(15,30,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(16,31,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(17,32,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(18,33,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(19,34,2,'\'2020-04-16 16:55:41\'',NULL,'Iniciada',NULL,NULL),(20,35,1,'\'2020-04-16 17:03:27\'',NULL,'Iniciada',NULL,NULL),(34,96,2,'\'2020-05-18 12:23:10\'',NULL,'Iniciada',NULL,NULL),(35,97,2,'\'2020-05-18 12:23:10\'',NULL,'Iniciada',NULL,NULL),(36,98,2,'\'2020-05-18 12:23:10\'',NULL,'Iniciada',NULL,NULL),(37,99,2,'\'2020-05-18 12:23:10\'',NULL,'Iniciada',NULL,NULL),(38,100,2,'\'2020-05-18 12:23:11\'',NULL,'Iniciada',NULL,NULL),(39,101,2,'\'2020-05-18 12:23:12\'',NULL,'Iniciada',NULL,NULL),(40,102,2,'\'2020-05-18 12:23:12\'',NULL,'Iniciada',NULL,NULL);
/*!40000 ALTER TABLE `actividades_proceso` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_vistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_vistas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_vistas_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_vistas_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_vistas` WRITE;
/*!40000 ALTER TABLE `actividades_vistas` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_vistas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `afp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `afp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `afp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `afp` WRITE;
/*!40000 ALTER TABLE `afp` DISABLE KEYS */;
INSERT INTO `afp` VALUES (1,'AFP Capital',NULL,NULL),(2,'AFP Cuprum',NULL,NULL),(3,'AFP Habitat',NULL,NULL),(4,'AFP Modelo',NULL,NULL),(5,'AFP Planvital',NULL,NULL),(6,'AFP Provida',NULL,NULL);
/*!40000 ALTER TABLE `afp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_gerencia` bigint(20) unsigned NOT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ubicacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `areas_area_unique` (`area`),
  KEY `areas_id_gerencia_foreign` (`id_gerencia`),
  CONSTRAINT `areas_id_gerencia_foreign` FOREIGN KEY (`id_gerencia`) REFERENCES `gerencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,1,'EWS','1D DCS Insp Estado SistCtrl 800xA Desal EWS','Planta Coloso-Antofagasta',NULL,NULL),(2,1,'Planta Cero/Desaladora & Acueducto','1D DCS Insp Estado SistCtrl 800xA Desal PLanta 0','Planta Coloso-Antofagasta',NULL,NULL),(3,1,'Agua y Tranque','Agua y Tranque','Feana-Mina',NULL,NULL),(4,2,'Filtro-Puerto','1D DCS Insp Estado SistCtrl 800xA Planta Filtro-Puerto','Planta Coloso-Antofagasta',NULL,NULL),(5,2,'ECT','1D DCS Insp Estado SistCtrl 800xA Planta ECT','Planta Coloso-Antofagasta',NULL,NULL),(6,2,'Los Colorados','DCS Insp Estado SistCtrl Bailey  Planta Los Colorados','Feana-Mina',NULL,NULL);
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `areas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `areas_empresa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `area_e` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `areas_empresa` WRITE;
/*!40000 ALTER TABLE `areas_empresa` DISABLE KEYS */;
INSERT INTO `areas_empresa` VALUES (1,'Administración',NULL,NULL),(2,'Proyectos',NULL,NULL),(3,'Equipo MEL',NULL,NULL),(4,'Equipo BHP',NULL,NULL);
/*!40000 ALTER TABLE `areas_empresa` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `motivo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dias_previos` int(11) NOT NULL,
  `dias_post` int(11) NOT NULL,
  `modalidad` enum('Automático','Manual','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Automático',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
INSERT INTO `avisos` VALUES (1,'Vencimiento de Licencia','Buenos días, Tardes o Noches. Le informamos que la fecha de vencimiento de su licencia esta llegando a la fecha, por lo que necesitamos que realice los procedimientos pertinentes para renovar su licencia, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',5,5,'Automático',NULL,NULL),(2,'Vencimiento de Exámenes','Buenos días, Tardes o Noches. Le informamos que existen ciertos exámenes que debe realizarse como cumplimiento a las normativas de salubridad de nuestra empresa, por lo que necesitamos que realice los procedimientos pertinentes para entregar los resultados en la oficina pertinente, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',5,5,'Ambos',NULL,NULL),(3,'Vencimiento de Cursos','Buenos días, Tardes o Noches. Le informamos que existen ciertos cursos que debe realizarse como cumplimiento a las normativas de nuestra empresa, por lo que necesitamos que realice los procedimientos pertinentes para entregar los resultados en la oficina pertinente, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',30,10,'Ambos',NULL,NULL);
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `avisos_enviados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos_enviados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_aviso` bigint(20) unsigned NOT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `status` enum('Enviado','Respondido','Respondido-Cumplido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Enviado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `avisos_enviados_id_aviso_foreign` (`id_aviso`),
  KEY `avisos_enviados_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `avisos_enviados_id_aviso_foreign` FOREIGN KEY (`id_aviso`) REFERENCES `avisos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `avisos_enviados_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `avisos_enviados` WRITE;
/*!40000 ALTER TABLE `avisos_enviados` DISABLE KEYS */;
INSERT INTO `avisos_enviados` VALUES (1,2,3,'Enviado','2020-04-02 04:00:00',NULL),(2,2,3,'Enviado','2020-04-02 04:00:00',NULL),(3,2,3,'Enviado','2020-04-06 04:00:00',NULL),(4,2,3,'Enviado','2020-04-06 04:00:00',NULL),(5,2,3,'Enviado','2020-04-06 04:00:00',NULL),(6,2,3,'Enviado','2020-04-06 04:00:00',NULL),(7,2,3,'Enviado','2020-04-06 04:00:00',NULL),(8,2,3,'Enviado','2020-04-08 04:00:00',NULL),(9,2,3,'Enviado','2020-04-08 04:00:00',NULL),(10,2,3,'Enviado','2020-04-08 04:00:00',NULL),(11,2,3,'Enviado','2020-04-08 04:00:00',NULL),(12,2,3,'Enviado','2020-04-08 04:00:00',NULL),(13,2,3,'Enviado','2020-04-10 04:00:00',NULL),(14,2,3,'Enviado','2020-04-10 04:00:00',NULL),(15,2,3,'Enviado','2020-04-10 04:00:00',NULL),(16,2,3,'Enviado','2020-04-10 04:00:00',NULL),(17,2,3,'Enviado','2020-04-10 04:00:00',NULL),(18,2,3,'Enviado','2020-04-13 04:00:00',NULL),(19,2,3,'Enviado','2020-04-13 04:00:00',NULL),(20,2,3,'Enviado','2020-04-13 04:00:00',NULL),(21,2,3,'Enviado','2020-04-13 04:00:00',NULL),(22,2,3,'Enviado','2020-04-13 04:00:00',NULL),(23,2,3,'Enviado','2020-04-14 04:00:00',NULL),(24,2,3,'Enviado','2020-04-14 04:00:00',NULL),(25,2,3,'Enviado','2020-04-14 04:00:00',NULL),(26,2,3,'Enviado','2020-04-14 04:00:00',NULL),(27,2,3,'Enviado','2020-04-14 04:00:00',NULL),(28,2,3,'Enviado','2020-04-16 04:00:00',NULL),(29,2,3,'Enviado','2020-04-16 04:00:00',NULL),(30,2,3,'Enviado','2020-04-16 04:00:00',NULL),(31,2,3,'Enviado','2020-04-16 04:00:00',NULL),(32,2,3,'Enviado','2020-04-16 04:00:00',NULL),(33,2,3,'Enviado','2020-04-18 04:00:00',NULL),(34,2,3,'Enviado','2020-04-18 04:00:00',NULL),(35,2,3,'Enviado','2020-04-18 04:00:00',NULL),(36,2,3,'Enviado','2020-04-18 04:00:00',NULL),(37,2,3,'Enviado','2020-04-18 04:00:00',NULL),(38,2,3,'Enviado','2020-04-25 04:00:00',NULL),(39,2,3,'Enviado','2020-04-25 04:00:00',NULL),(40,2,3,'Enviado','2020-04-25 04:00:00',NULL),(41,2,3,'Enviado','2020-04-25 04:00:00',NULL),(42,2,3,'Enviado','2020-04-25 04:00:00',NULL),(43,2,3,'Enviado','2020-05-06 04:00:00',NULL),(44,2,3,'Enviado','2020-05-06 04:00:00',NULL),(45,2,3,'Enviado','2020-05-06 04:00:00',NULL),(46,2,3,'Enviado','2020-05-06 04:00:00',NULL),(47,2,3,'Enviado','2020-05-06 04:00:00',NULL),(48,2,3,'Enviado','2020-05-07 04:00:00',NULL),(49,2,3,'Enviado','2020-05-07 04:00:00',NULL),(50,2,3,'Enviado','2020-05-07 04:00:00',NULL),(51,2,3,'Enviado','2020-05-07 04:00:00',NULL),(52,2,3,'Enviado','2020-05-07 04:00:00',NULL),(53,2,3,'Enviado','2020-05-07 04:00:00',NULL),(54,2,3,'Enviado','2020-05-07 04:00:00',NULL),(55,2,3,'Enviado','2020-05-07 04:00:00',NULL),(56,2,3,'Enviado','2020-05-07 04:00:00',NULL),(57,2,3,'Enviado','2020-05-07 04:00:00',NULL),(58,2,3,'Enviado','2020-05-08 04:00:00',NULL),(59,2,3,'Enviado','2020-05-08 04:00:00',NULL),(60,2,3,'Enviado','2020-05-08 04:00:00',NULL),(61,2,3,'Enviado','2020-05-08 04:00:00',NULL),(62,2,3,'Enviado','2020-05-08 04:00:00',NULL),(63,2,3,'Enviado','2020-05-11 04:00:00',NULL),(64,2,3,'Enviado','2020-05-11 04:00:00',NULL),(65,2,3,'Enviado','2020-05-11 04:00:00',NULL),(66,2,3,'Enviado','2020-05-11 04:00:00',NULL),(67,2,3,'Enviado','2020-05-11 04:00:00',NULL),(68,2,3,'Enviado','2020-05-12 04:00:00',NULL),(69,2,3,'Enviado','2020-05-12 04:00:00',NULL),(70,2,3,'Enviado','2020-05-12 04:00:00',NULL),(71,2,3,'Enviado','2020-05-12 04:00:00',NULL),(72,2,3,'Enviado','2020-05-12 04:00:00',NULL),(73,2,3,'Enviado','2020-05-15 04:00:00',NULL),(74,2,3,'Enviado','2020-05-15 04:00:00',NULL),(75,2,3,'Enviado','2020-05-15 04:00:00',NULL),(76,2,3,'Enviado','2020-05-15 04:00:00',NULL),(77,2,3,'Enviado','2020-05-15 04:00:00',NULL),(78,2,3,'Enviado','2020-05-19 04:00:00',NULL),(79,2,3,'Enviado','2020-05-19 04:00:00',NULL),(80,2,3,'Enviado','2020-05-19 04:00:00',NULL),(81,2,3,'Enviado','2020-05-19 04:00:00',NULL),(82,2,3,'Enviado','2020-05-19 04:00:00',NULL),(83,2,3,'Enviado','2020-05-28 04:00:00',NULL),(84,2,3,'Enviado','2020-05-28 04:00:00',NULL),(85,2,3,'Enviado','2020-05-28 04:00:00',NULL),(86,2,3,'Enviado','2020-05-28 04:00:00',NULL),(87,2,3,'Enviado','2020-05-28 04:00:00',NULL),(88,2,3,'Enviado','2020-06-19 04:00:00',NULL),(89,2,3,'Enviado','2020-06-19 04:00:00',NULL),(90,2,3,'Enviado','2020-06-19 04:00:00',NULL),(91,2,3,'Enviado','2020-06-19 04:00:00',NULL),(92,2,3,'Enviado','2020-06-19 04:00:00',NULL),(93,2,3,'Enviado','2020-06-20 04:00:00',NULL),(94,2,3,'Enviado','2020-06-22 04:00:00',NULL),(95,2,3,'Enviado','2020-06-22 04:00:00',NULL),(96,2,3,'Enviado','2020-06-22 04:00:00',NULL),(97,2,3,'Enviado','2020-06-22 04:00:00',NULL),(98,2,3,'Enviado','2020-06-22 04:00:00',NULL);
/*!40000 ALTER TABLE `avisos_enviados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `comentarios_vistos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentarios_vistos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_comentario` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_actividad` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comentarios_vistos_id_comentario_foreign` (`id_comentario`),
  CONSTRAINT `comentarios_vistos_id_comentario_foreign` FOREIGN KEY (`id_comentario`) REFERENCES `actividades_comentarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `comentarios_vistos` WRITE;
/*!40000 ALTER TABLE `comentarios_vistos` DISABLE KEYS */;
/*!40000 ALTER TABLE `comentarios_vistos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `curso` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'Cero Daño MEL','Activo',NULL,NULL),(2,'Inducción de Area MEL','Activo',NULL,NULL),(3,'Hombre Nuevo Centinela','Activo',NULL,NULL),(4,'Altura','Activo',NULL,NULL),(5,'Inducción de Area Centinela','Activo',NULL,NULL),(6,'HCR30 Centinela','Activo',NULL,NULL),(7,'Primeros Auxilios Centinela','Activo',NULL,NULL),(8,'Extintores Centinela','Activo',NULL,NULL),(9,'Orientación en Prev. De Riesgos Centinela','Activo',NULL,NULL),(10,'Reg. De Emergencia Centinela','Activo',NULL,NULL),(11,'Servicio Salud Centinela','Activo',NULL,NULL),(12,'Aislación y Bloqueo Centinela','Activo',NULL,NULL);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_laborales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datos_laborales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `fechai_vac` date DEFAULT NULL,
  `fechaf_vac` date DEFAULT NULL,
  `status_vac` enum('Solicitadas','Aprobada','Negada','Sin Solicitar') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sin Solicitar',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_laborales_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `datos_laborales_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_laborales` WRITE;
/*!40000 ALTER TABLE `datos_laborales` DISABLE KEYS */;
INSERT INTO `datos_laborales` VALUES (1,2,'2019-12-17','2019-12-20','Solicitadas',NULL,NULL);
/*!40000 ALTER TABLE `datos_laborales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_varios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datos_varios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `segundo_nombre` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `segundo_apellido` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_nac` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_varios_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `datos_varios_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_varios` WRITE;
/*!40000 ALTER TABLE `datos_varios` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_varios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departamentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `departamento` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES (1,'Ninguno',NULL,NULL),(2,'Comunicaciones',NULL,NULL),(3,'Mantención',NULL,NULL),(4,'Operación',NULL,NULL),(5,'Control de Procesos',NULL,NULL),(6,'DCS',NULL,NULL);
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `nombres` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edad` int(11) NOT NULL,
  `cargo` enum('Gerente','Jefe de Operaciones','Ingeniero de Servicios','Jefe de Administración','Técnico de Servicios','Ingeniero en Entrenamiento','Maestro Mayor','Jefe de Terreno','Supervisor de Terreno','Técnico de Montaje','Jefe de Coordinación y Gestión','Planificador','Prevención de Riesgos','Asistente Administrativo','Chofer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `genero` enum('Masculino','Femenino') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Masculino',
  `status` enum('Activo','Reposo','Retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `empleados_email_unique` (`email`),
  KEY `empleados_id_usuario_foreign` (`id_usuario`),
  CONSTRAINT `empleados_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,3,'María José','Varas','m.varas@licancabur.cl','122456789',30,'Gerente','Masculino','Activo',NULL,NULL),(2,5,'Terreno','Terreno','terreno@licancabur.cl','123456789',30,'Gerente','Masculino','Activo',NULL,NULL),(3,1,'R','Portilla','r.portilla@licancabur.cl','12345189',30,'Gerente','Masculino','Activo',NULL,NULL);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_afp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_afp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_afp` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_afp_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_afp_id_afp_foreign` (`id_afp`),
  CONSTRAINT `empleados_has_afp_id_afp_foreign` FOREIGN KEY (`id_afp`) REFERENCES `afp` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_afp_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_afp` WRITE;
/*!40000 ALTER TABLE `empleados_has_afp` DISABLE KEYS */;
INSERT INTO `empleados_has_afp` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,5,NULL,NULL),(6,1,6,NULL,NULL),(7,2,1,NULL,NULL),(8,2,2,NULL,NULL),(9,2,3,NULL,NULL),(10,2,4,NULL,NULL),(11,2,5,NULL,NULL),(12,2,6,NULL,NULL),(13,1,1,NULL,NULL),(14,1,2,NULL,NULL),(15,1,3,NULL,NULL),(16,1,4,NULL,NULL),(17,1,5,NULL,NULL),(18,1,6,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_afp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_area` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_areas_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_areas_id_area_foreign` (`id_area`),
  CONSTRAINT `empleados_has_areas_id_area_foreign` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_areas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_areas` WRITE;
/*!40000 ALTER TABLE `empleados_has_areas` DISABLE KEYS */;
INSERT INTO `empleados_has_areas` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,5,NULL,NULL),(6,1,6,NULL,NULL),(7,2,1,NULL,NULL),(8,2,2,NULL,NULL),(9,2,4,NULL,NULL),(10,3,1,NULL,NULL),(11,3,2,NULL,NULL),(12,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_areas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_areas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_areas_empresa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_area_e` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_areas_empresa_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_areas_empresa_id_area_e_foreign` (`id_area_e`),
  CONSTRAINT `empleados_has_areas_empresa_id_area_e_foreign` FOREIGN KEY (`id_area_e`) REFERENCES `areas_empresa` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_areas_empresa_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_areas_empresa` WRITE;
/*!40000 ALTER TABLE `empleados_has_areas_empresa` DISABLE KEYS */;
INSERT INTO `empleados_has_areas_empresa` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,2,NULL,NULL),(6,3,3,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_areas_empresa` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_cursos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_curso` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_cursos_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_cursos_id_curso_foreign` (`id_curso`),
  CONSTRAINT `empleados_has_cursos_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_cursos_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_cursos` WRITE;
/*!40000 ALTER TABLE `empleados_has_cursos` DISABLE KEYS */;
INSERT INTO `empleados_has_cursos` VALUES (1,1,1,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(2,1,2,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(3,1,3,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(4,1,4,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(5,1,5,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(6,2,1,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(7,2,2,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(8,2,3,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(9,2,4,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(10,2,5,'2019-06-15','2019-01-15','Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_cursos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_departamentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_departamento` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_departamentos_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_departamentos_id_departamento_foreign` (`id_departamento`),
  CONSTRAINT `empleados_has_departamentos_id_departamento_foreign` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_departamentos_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_departamentos` WRITE;
/*!40000 ALTER TABLE `empleados_has_departamentos` DISABLE KEYS */;
INSERT INTO `empleados_has_departamentos` VALUES (1,1,2,NULL,NULL),(2,1,3,NULL,NULL),(3,1,4,NULL,NULL),(4,1,5,NULL,NULL),(5,1,6,NULL,NULL),(6,2,2,NULL,NULL),(7,2,4,NULL,NULL),(8,3,2,NULL,NULL),(9,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_departamentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_examenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_examen` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_examenes_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_examenes_id_examen_foreign` (`id_examen`),
  CONSTRAINT `empleados_has_examenes_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_examenes_id_examen_foreign` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_examenes` WRITE;
/*!40000 ALTER TABLE `empleados_has_examenes` DISABLE KEYS */;
INSERT INTO `empleados_has_examenes` VALUES (1,1,1,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(2,1,2,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(3,1,3,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(4,1,4,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(5,1,5,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(6,2,1,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(7,2,2,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(8,2,3,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(9,2,4,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(10,2,5,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(11,3,1,'2019-05-15',NULL,'Entregado',NULL,NULL),(12,3,2,'2019-05-15',NULL,'Entregado',NULL,NULL),(13,3,3,'2019-05-15',NULL,'Entregado',NULL,NULL),(14,3,4,'2019-05-15',NULL,'Entregado',NULL,NULL),(15,3,5,'2019-05-15',NULL,'Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_examenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_faenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_faenas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_faena` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_faenas_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_faenas_id_faena_foreign` (`id_faena`),
  CONSTRAINT `empleados_has_faenas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_faenas_id_faena_foreign` FOREIGN KEY (`id_faena`) REFERENCES `faenas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_faenas` WRITE;
/*!40000 ALTER TABLE `empleados_has_faenas` DISABLE KEYS */;
INSERT INTO `empleados_has_faenas` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,2,1,NULL,NULL),(6,2,2,NULL,NULL),(7,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_faenas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_licencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_has_licencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_licencia` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_licencias_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_licencias_id_licencia_foreign` (`id_licencia`),
  CONSTRAINT `empleados_has_licencias_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_licencias_id_licencia_foreign` FOREIGN KEY (`id_licencia`) REFERENCES `licencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_licencias` WRITE;
/*!40000 ALTER TABLE `empleados_has_licencias` DISABLE KEYS */;
INSERT INTO `empleados_has_licencias` VALUES (1,1,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL),(2,2,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL),(3,3,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_licencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `examen` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `examenes` WRITE;
/*!40000 ALTER TABLE `examenes` DISABLE KEYS */;
INSERT INTO `examenes` VALUES (1,'Altura Geográfica',NULL,'Activo',NULL,NULL),(2,'Altura Física',NULL,'Activo',NULL,NULL),(3,'Adversión al riesgo',NULL,'Activo',NULL,NULL),(4,'Alcohol',NULL,'Activo',NULL,NULL),(5,'Drogas',NULL,'Activo',NULL,NULL),(6,'Psicosensométrico',NULL,'Activo',NULL,NULL);
/*!40000 ALTER TABLE `examenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faenas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faena` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faenas` WRITE;
/*!40000 ALTER TABLE `faenas` DISABLE KEYS */;
INSERT INTO `faenas` VALUES (1,'MEL',NULL,NULL),(2,'Centinela',NULL,NULL),(3,'SQM',NULL,NULL),(4,'R.T.',NULL,NULL);
/*!40000 ALTER TABLE `faenas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `gerencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gerencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gerencia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `gerencias` WRITE;
/*!40000 ALTER TABLE `gerencias` DISABLE KEYS */;
INSERT INTO `gerencias` VALUES (1,'NPI',NULL,NULL),(2,'CHO',NULL,NULL);
/*!40000 ALTER TABLE `gerencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informacion_contacto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `informacion_contacto` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `informacion_contacto_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `informacion_contacto_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informacion_contacto` WRITE;
/*!40000 ALTER TABLE `informacion_contacto` DISABLE KEYS */;
/*!40000 ALTER TABLE `informacion_contacto` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `licencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `licencia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `licencias` WRITE;
/*!40000 ALTER TABLE `licencias` DISABLE KEYS */;
INSERT INTO `licencias` VALUES (1,'De Conducir','Activo',NULL,NULL);
/*!40000 ALTER TABLE `licencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_16_195341_create_gerencias_table',1),(4,'2019_08_18_153028_create_departamentos_table',1),(5,'2019_08_19_011947_create_areas_table',1),(6,'2019_08_19_012034_create_empleados_table',1),(7,'2019_08_19_152718_create_planificacion_table',1),(8,'2019_08_19_152728_create_actividades_table',1),(9,'2019_08_19_153125_create_actividades_has_archivos_table',1),(10,'2019_08_19_153622_create_actividades_proceso_table',1),(11,'2019_08_19_153911_create_actividades_comentarios_table',1),(12,'2019_08_19_154133_create_actividades_adjuntos_table',1),(13,'2019_09_27_214046_create_privilegios_table',1),(14,'2019_09_27_214409_create_usuarios_has_privilegios_table',1),(15,'2019_11_13_161958_create_comentarios_vistos_table',1),(16,'2019_11_13_162314_create_actividades_vistas_table',1),(17,'2019_11_21_153417_create_empleados_has_areas_table',1),(18,'2019_12_04_144106_create_empleados_has_departamentos',1),(19,'2019_12_16_125753_create_examenes_table',1),(20,'2019_12_16_125925_create_empleados_has_examenes_table',1),(21,'2019_12_16_130515_create_datos_laborales_table',1),(22,'2019_12_23_153808_create_notas_table',1),(23,'2020_01_08_124252_create_muros_table',1),(24,'2020_01_27_162422_create_novedades_table',1),(25,'2020_02_07_224328_create_avisos_table',1),(26,'2020_02_07_224643_create_avisos_enviados_table',1),(27,'2020_02_09_173336_create_cursos_table',1),(28,'2020_02_09_173421_create_empleados_has_cursos_table',1),(29,'2020_02_09_181746_create_areas_empresa_table',1),(30,'2020_02_09_181818_create_afp_table',1),(31,'2020_02_09_181846_create_faenas_table',1),(32,'2020_02_09_182032_create_empleados_has_areas_empresa_table',1),(33,'2020_02_09_182241_create_empleados_has_afp_table',1),(34,'2020_02_09_182303_create_empleados_has_faenas_table',1),(35,'2020_02_13_164635_create_informacion_contacto_table',1),(36,'2020_02_13_165154_create_datos_varios_table',1),(37,'2020_03_13_005852_create_licencias_table',1),(38,'2020_03_13_010111_create_empleados_has_licencias_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `muros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `muros` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `comentario` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `muros_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `muros_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `muros` WRITE;
/*!40000 ALTER TABLE `muros` DISABLE KEYS */;
/*!40000 ALTER TABLE `muros` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `notas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notas_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `notas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `novedades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `novedad` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` enum('actividad','nuevo_user','notificacion','muro','EICHE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` time NOT NULL,
  `hora` datetime NOT NULL,
  `id_usuario_n` bigint(20) unsigned DEFAULT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `novedades_id_usuario_n_foreign` (`id_usuario_n`),
  KEY `novedades_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `novedades_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `novedades_id_usuario_n_foreign` FOREIGN KEY (`id_usuario_n`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `novedades` WRITE;
/*!40000 ALTER TABLE `novedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `novedades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `planificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `planificacion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `elaborado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aprobado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_contrato` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semana` int(11) NOT NULL,
  `revision` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A',
  `id_gerencia` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planificacion_id_gerencia_foreign` (`id_gerencia`),
  CONSTRAINT `planificacion_id_gerencia_foreign` FOREIGN KEY (`id_gerencia`) REFERENCES `gerencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `planificacion` WRITE;
/*!40000 ALTER TABLE `planificacion` DISABLE KEYS */;
INSERT INTO `planificacion` VALUES (1,'María José Varas','Gabriel Olmos','9100008366','01-01-2020 al 07-01-2020',1,'A',1,NULL,NULL),(2,'María José Varas','Gabriel Olmos','9100008366','01-01-2020 al 07-01-2020',1,'A',2,NULL,NULL),(3,'María José Varas','Gabriel Olmos','9100008366','08-01-2020 al 14-01-2020',2,'A',1,NULL,NULL),(4,'María José Varas','Gabriel Olmos','9100008366','08-01-2020 al 14-01-2020',2,'A',2,NULL,NULL),(5,'María José Varas','Gabriel Olmos','9100008366','15-01-2020 al 21-01-2020',3,'A',1,NULL,NULL),(6,'María José Varas','Gabriel Olmos','9100008366','15-01-2020 al 21-01-2020',3,'A',2,NULL,NULL),(7,'María José Varas','Gabriel Olmos','9100008366','22-01-2020 al 28-01-2020',4,'A',1,NULL,NULL),(8,'María José Varas','Gabriel Olmos','9100008366','22-01-2020 al 28-01-2020',4,'A',2,NULL,NULL),(9,'María José Varas','Gabriel Olmos','9100008366','29-01-2020 al 04-02-2020',5,'A',1,NULL,NULL),(10,'María José Varas','Gabriel Olmos','9100008366','29-01-2020 al 04-02-2020',5,'A',2,NULL,NULL),(11,'María José Varas','Gabriel Olmos','9100008366','05-02-2020 al 11-11-2020',6,'A',1,NULL,NULL),(12,'María José Varas','Gabriel Olmos','9100008366','05-02-2020 al 11-11-2020',6,'A',2,NULL,NULL),(13,'María José Varas','Gabriel Olmos','9100008366','12-02-2020 al 18-02-2020',7,'A',1,NULL,NULL),(14,'María José Varas','Gabriel Olmos','9100008366','12-02-2020 al 18-02-2020',7,'A',2,NULL,NULL),(15,'María José Varas','Gabriel Olmos','9100008366','19-02-2020 al 25-02-2020',8,'A',1,NULL,NULL),(16,'María José Varas','Gabriel Olmos','9100008366','19-02-2020 al 25-02-2020',8,'A',2,NULL,NULL),(17,'María José Varas','Gabriel Olmos','9100008366','26-02-2020 al 03-03-2020',9,'A',1,NULL,NULL),(18,'María José Varas','Gabriel Olmos','9100008366','26-02-2020 al 03-03-2020',9,'A',2,NULL,NULL),(19,'María José Varas','Gabriel Olmos','9100008366','04-03-2020 al 10-03-2020',10,'A',1,NULL,NULL),(20,'María José Varas','Gabriel Olmos','9100008366','04-03-2020 al 10-03-2020',10,'A',2,NULL,NULL),(21,'María José Varas','Gabriel Olmos','9100008366','11-03-2020 al 17-03-2020',11,'A',1,NULL,NULL),(22,'María José Varas','Gabriel Olmos','9100008366','11-03-2020 al 17-03-2020',11,'A',2,NULL,NULL),(23,'María José Varas','Gabriel Olmos','9100008366','18-03-2020 al 24-03-2020',12,'A',1,NULL,NULL),(24,'María José Varas','Gabriel Olmos','9100008366','18-03-2020 al 24-03-2020',12,'A',2,NULL,NULL),(25,'María José Varas','Gabriel Olmos','9100008366','25-03-2020 al 31-03-2020',13,'A',1,NULL,NULL),(26,'María José Varas','Gabriel Olmos','9100008366','25-03-2020 al 31-03-2020',13,'A',2,NULL,NULL),(27,'María José Varas','Gabriel Olmos','9100008366','01-04-2020 al 07-04-2020',14,'A',1,NULL,NULL),(28,'María José Varas','Gabriel Olmos','9100008366','01-04-2020 al 07-04-2020',14,'A',2,NULL,NULL),(29,'María José Varas','Gabriel Olmos','9100008366','08-04-2020 al 14-04-2020',15,'A',1,NULL,NULL),(30,'María José Varas','Gabriel Olmos','9100008366','08-04-2020 al 14-04-2020',15,'A',2,NULL,NULL),(31,'María José Varas','Gabriel Olmos','9100008366','15-04-2020 al 21-04-2020',16,'A',1,NULL,NULL),(32,'María José Varas','Gabriel Olmos','9100008366','15-04-2020 al 21-04-2020',16,'A',2,NULL,NULL),(33,'María José Varas','Gabriel Olmos','9100008366','22-04-2020 al 28-04-2020',17,'A',1,NULL,NULL),(34,'María José Varas','Gabriel Olmos','9100008366','22-04-2020 al 28-04-2020',17,'A',2,NULL,NULL),(35,'María José Varas','Gabriel Olmos','9100008366','29-04-2020 al 05-05-2020',18,'A',1,NULL,NULL),(36,'María José Varas','Gabriel Olmos','9100008366','29-04-2020 al 05-05-2020',18,'A',2,NULL,NULL),(37,'María José Varas','Gabriel Olmos','9100008366','06-05-2020 al 12-05-2020',19,'A',1,NULL,NULL),(38,'María José Varas','Gabriel Olmos','9100008366','06-05-2020 al 12-05-2020',19,'A',2,NULL,NULL),(39,'María José Varas','Gabriel Olmos','9100008366','13-05-2020 al 19-05-2020',20,'A',1,NULL,NULL),(40,'María José Varas','Gabriel Olmos','9100008366','13-05-2020 al 19-05-2020',20,'A',2,NULL,NULL),(41,'María José Varas','Gabriel Olmos','9100008366','20-05-2020 al 26-05-2020',21,'A',1,NULL,NULL),(42,'María José Varas','Gabriel Olmos','9100008366','20-05-2020 al 26-05-2020',21,'A',2,NULL,NULL),(43,'María José Varas','Gabriel Olmos','9100008366','27-05-2020 al 02-06-2020',22,'A',1,NULL,NULL),(44,'María José Varas','Gabriel Olmos','9100008366','27-05-2020 al 02-06-2020',22,'A',2,NULL,NULL),(45,'María José Varas','Gabriel Olmos','9100008366','03-06-2020 al 09-06-2020',23,'A',1,NULL,NULL),(46,'María José Varas','Gabriel Olmos','9100008366','03-06-2020 al 09-06-2020',23,'A',2,NULL,NULL),(47,'María José Varas','Gabriel Olmos','9100008366','10-06-2020 al 16-06-2020',24,'A',1,NULL,NULL),(48,'María José Varas','Gabriel Olmos','9100008366','10-06-2020 al 16-06-2020',24,'A',2,NULL,NULL),(49,'María José Varas','Gabriel Olmos','9100008366','17-06-2020 al 23-06-2020',25,'A',1,NULL,NULL),(50,'María José Varas','Gabriel Olmos','9100008366','17-06-2020 al 23-06-2020',25,'A',2,NULL,NULL),(51,'María José Varas','Gabriel Olmos','9100008366','24-06-2020 al 30-06-2020',26,'A',1,NULL,NULL),(52,'María José Varas','Gabriel Olmos','9100008366','24-06-2020 al 30-06-2020',26,'A',2,NULL,NULL),(53,'María José Varas','Gabriel Olmos','9100008366','01-07-2020 al 07-07-2020',27,'A',1,NULL,NULL),(54,'María José Varas','Gabriel Olmos','9100008366','01-07-2020 al 07-07-2020',27,'A',2,NULL,NULL),(55,'María José Varas','Gabriel Olmos','9100008366','08-07-2020 al 14-07-2020',28,'A',1,NULL,NULL),(56,'María José Varas','Gabriel Olmos','9100008366','08-07-2020 al 14-07-2020',28,'A',2,NULL,NULL),(57,'María José Varas','Gabriel Olmos','9100008366','15-07-2020 al 21-07-2020',29,'A',1,NULL,NULL),(58,'María José Varas','Gabriel Olmos','9100008366','15-07-2020 al 21-07-2020',29,'A',2,NULL,NULL),(59,'María José Varas','Gabriel Olmos','9100008366','22-07-2020 al 28-07-2020',30,'A',1,NULL,NULL),(60,'María José Varas','Gabriel Olmos','9100008366','22-07-2020 al 28-07-2020',30,'A',2,NULL,NULL),(61,'María José Varas','Gabriel Olmos','9100008366','29-07-2020 al 04-08-2020',31,'A',1,NULL,NULL),(62,'María José Varas','Gabriel Olmos','9100008366','29-07-2020 al 04-08-2020',31,'A',2,NULL,NULL),(63,'María José Varas','Gabriel Olmos','9100008366','05-08-2020 al 11-08-2020',32,'A',1,NULL,NULL),(64,'María José Varas','Gabriel Olmos','9100008366','05-08-2020 al 11-08-2020',32,'A',2,NULL,NULL),(65,'María José Varas','Gabriel Olmos','9100008366','12-08-2020 al 18-08-2020',33,'A',1,NULL,NULL),(66,'María José Varas','Gabriel Olmos','9100008366','12-08-2020 al 18-08-2020',33,'A',2,NULL,NULL),(67,'María José Varas','Gabriel Olmos','9100008366','19-08-2020 al 25-08-2020',34,'A',1,NULL,NULL),(68,'María José Varas','Gabriel Olmos','9100008366','19-08-2020 al 25-08-2020',34,'A',2,NULL,NULL),(69,'María José Varas','Gabriel Olmos','9100008366','26-08-2020 al 01-09-2020',35,'A',1,NULL,NULL),(70,'María José Varas','Gabriel Olmos','9100008366','26-08-2020 al 01-09-2020',35,'A',2,NULL,NULL),(71,'María José Varas','Gabriel Olmos','9100008366','02-09-2020 al 08-09-2020',36,'A',1,NULL,NULL),(72,'María José Varas','Gabriel Olmos','9100008366','02-09-2020 al 08-09-2020',36,'A',2,NULL,NULL),(73,'María José Varas','Gabriel Olmos','9100008366','09-09-2020 al 15-09-2020',37,'A',1,NULL,NULL),(74,'María José Varas','Gabriel Olmos','9100008366','09-09-2020 al 15-09-2020',37,'A',2,NULL,NULL),(75,'María José Varas','Gabriel Olmos','9100008366','16-09-2020 al 22-09-2020',38,'A',1,NULL,NULL),(76,'María José Varas','Gabriel Olmos','9100008366','16-09-2020 al 22-09-2020',38,'A',2,NULL,NULL),(77,'María José Varas','Gabriel Olmos','9100008366','23-09-2020 al 29-09-2020',39,'A',1,NULL,NULL),(78,'María José Varas','Gabriel Olmos','9100008366','23-09-2020 al 29-09-2020',39,'A',2,NULL,NULL),(79,'María José Varas','Gabriel Olmos','9100008366','30-09-2020 al 06-10-2020',40,'A',1,NULL,NULL),(80,'María José Varas','Gabriel Olmos','9100008366','30-09-2020 al 06-10-2020',40,'A',2,NULL,NULL),(81,'María José Varas','Gabriel Olmos','9100008366','07-10-2020 al 13-10-2020',41,'A',1,NULL,NULL),(82,'María José Varas','Gabriel Olmos','9100008366','07-10-2020 al 13-10-2020',41,'A',2,NULL,NULL),(83,'María José Varas','Gabriel Olmos','9100008366','14-10-2020 al 20-10-2020',42,'A',1,NULL,NULL),(84,'María José Varas','Gabriel Olmos','9100008366','14-10-2020 al 20-10-2020',42,'A',2,NULL,NULL),(85,'María José Varas','Gabriel Olmos','9100008366','21-10-2020 al 27-10-2020',43,'A',1,NULL,NULL),(86,'María José Varas','Gabriel Olmos','9100008366','21-10-2020 al 27-10-2020',43,'A',2,NULL,NULL),(87,'María José Varas','Gabriel Olmos','9100008366','28-10-2020 al 03-11-2020',44,'A',1,NULL,NULL),(88,'María José Varas','Gabriel Olmos','9100008366','28-10-2020 al 03-11-2020',44,'A',2,NULL,NULL),(89,'María José Varas','Gabriel Olmos','9100008366','04-11-2020 al 10-11-2020',45,'A',1,NULL,NULL),(90,'María José Varas','Gabriel Olmos','9100008366','04-11-2020 al 10-11-2020',45,'A',2,NULL,NULL),(91,'María José Varas','Gabriel Olmos','9100008366','11-11-2020 al 17-11-2020',46,'A',1,NULL,NULL),(92,'María José Varas','Gabriel Olmos','9100008366','11-11-2020 al 17-11-2020',46,'A',2,NULL,NULL),(93,'María José Varas','Gabriel Olmos','9100008366','18-11-2020 al 24-11-2020',47,'A',1,NULL,NULL),(94,'María José Varas','Gabriel Olmos','9100008366','18-11-2020 al 24-11-2020',47,'A',2,NULL,NULL),(95,'María José Varas','Gabriel Olmos','9100008366','25-11-2020 al 01-12-2020',48,'A',1,NULL,NULL),(96,'María José Varas','Gabriel Olmos','9100008366','25-11-2020 al 01-12-2020',48,'A',2,NULL,NULL),(97,'María José Varas','Gabriel Olmos','9100008366','02-12-2020 al 08-12-2020',49,'A',1,NULL,NULL),(98,'María José Varas','Gabriel Olmos','9100008366','02-12-2020 al 08-12-2020',49,'A',2,NULL,NULL),(99,'María José Varas','Gabriel Olmos','9100008366','09-12-2020 al 15-12-2020',50,'A',1,NULL,NULL),(100,'María José Varas','Gabriel Olmos','9100008366','09-12-2020 al 15-12-2020',50,'A',2,NULL,NULL),(101,'María José Varas','Gabriel Olmos','9100008366','16-12-2020 al 22-12-2020',51,'A',1,NULL,NULL),(102,'María José Varas','Gabriel Olmos','9100008366','16-12-2020 al 22-12-2020',51,'A',2,NULL,NULL),(103,'María José Varas','Gabriel Olmos','9100008366','23-12-2020 al 29-12-2020',52,'A',1,NULL,NULL),(104,'María José Varas','Gabriel Olmos','9100008366','23-12-2020 al 29-12-2020',52,'A',2,NULL,NULL);
/*!40000 ALTER TABLE `planificacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `privilegios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `privilegios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `privilegio` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `privilegios` WRITE;
/*!40000 ALTER TABLE `privilegios` DISABLE KEYS */;
INSERT INTO `privilegios` VALUES (1,'Planificación','Buscar',NULL,NULL),(2,'Planificación','Registrar',NULL,NULL),(3,'Planificación','Modificar',NULL,NULL),(4,'Planificación','Eliminar',NULL,NULL),(5,'Actividades','Ver',NULL,NULL),(6,'Actividades','Registrar',NULL,NULL),(7,'Actividades','Registro de PM03',NULL,NULL),(8,'Actividades','Modificar',NULL,NULL),(9,'Actividades','Asignar',NULL,NULL),(10,'Actividades','Eliminar',NULL,NULL),(11,'Usuarios','Listado',NULL,NULL),(12,'Usuarios','Registrar',NULL,NULL),(13,'Usuarios','Modificar',NULL,NULL),(14,'Usuarios','Eliminar',NULL,NULL),(15,'Usuarios','Ver datos laborales',NULL,NULL),(16,'Usuarios','Ver examenes',NULL,NULL),(17,'Usuarios','Ver curso cero daño',NULL,NULL),(18,'Graficas','Ver',NULL,NULL),(19,'Reportes','Excel',NULL,NULL),(20,'Reportes','PDF',NULL,NULL),(21,'Areas','Listado',NULL,NULL),(22,'Areas','Registrar',NULL,NULL),(23,'Areas','Editar',NULL,NULL),(24,'Areas','Eliminar',NULL,NULL),(25,'Gerencias','Listado',NULL,NULL),(26,'Gerencias','Registrar',NULL,NULL),(27,'Gerencias','Editar',NULL,NULL),(28,'Gerencias','Eliminar',NULL,NULL),(29,'Departamentos','Listado',NULL,NULL),(30,'Departamentos','Registrar',NULL,NULL),(31,'Departamentos','Editar',NULL,NULL),(32,'Departamentos','Eliminar',NULL,NULL),(33,'Actividades - PM01','General',NULL,NULL),(34,'Actividades - PM02','General',NULL,NULL),(35,'Actividades - PM04','General',NULL,NULL);
/*!40000 ALTER TABLE `privilegios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_user` enum('Admin','Supervisor','Planificacion','Recursos humanos','Empleado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Empleado',
  `superUser` enum('Eiche','no') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'R Portilla','r.portilla@licancabur.cl',NULL,'$2y$10$AhVL6hAfkZlT3/JLqMIfauljF6ibTNmEHNIettW9TBpqDm3JKjD0a','Admin','no',NULL,NULL,NULL),(2,'G Olmos','g.olmos@licancabur.c',NULL,'$2y$10$Q1bfYei9ED.hW/IVVbHfYOGgveLFvzjuu0iHE8RDFVXgqryiV.xUe','Supervisor','no',NULL,NULL,NULL),(3,'María José Varas','m.varas@licancabur.cl',NULL,'$2y$10$aGPIUg1Gpx7o.sPOrWjtWOLm4TZCi2VTjNQuE3f9fP2QsvTH4muK2','Planificacion','no',NULL,NULL,NULL),(4,'A Portilla','a.portilla@licancabur.cl',NULL,'$2y$10$mpTsC1SsBEJ8SWbYoCQ2BePGmvoy4Fuj./Q/6/KpRYuyEDinWqq56','Recursos humanos','no',NULL,NULL,NULL),(5,'Terreno','terreno@licancabur.cl',NULL,'$2y$10$ecMGmVLNKIn5HY5IfhauvOEp0iFocy87I91F1OS8PNUygSaq4Xn7C','Empleado','no',NULL,NULL,NULL),(6,'Administrador EICHE','Admin@eiche.cl',NULL,'$2y$10$wDa.YJB.RUmB6cpWoZ/cPOfqs8s8EQHFGSOA4lme58bCrhb8VRoLm','Admin','Eiche',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `usuarios_has_privilegios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios_has_privilegios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `id_privilegio` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Si',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuarios_has_privilegios_id_usuario_foreign` (`id_usuario`),
  KEY `usuarios_has_privilegios_id_privilegio_foreign` (`id_privilegio`),
  CONSTRAINT `usuarios_has_privilegios_id_privilegio_foreign` FOREIGN KEY (`id_privilegio`) REFERENCES `privilegios` (`id`),
  CONSTRAINT `usuarios_has_privilegios_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `usuarios_has_privilegios` WRITE;
/*!40000 ALTER TABLE `usuarios_has_privilegios` DISABLE KEYS */;
INSERT INTO `usuarios_has_privilegios` VALUES (1,1,1,'Si',NULL,NULL),(2,1,2,'Si',NULL,NULL),(3,1,3,'Si',NULL,NULL),(4,1,4,'Si',NULL,NULL),(5,1,5,'Si',NULL,NULL),(6,1,6,'Si',NULL,NULL),(7,1,7,'Si',NULL,NULL),(8,1,8,'Si',NULL,NULL),(9,1,9,'Si',NULL,NULL),(10,1,10,'Si',NULL,NULL),(11,1,11,'Si',NULL,NULL),(12,1,12,'Si',NULL,NULL),(13,1,13,'Si',NULL,NULL),(14,1,14,'Si',NULL,NULL),(15,1,15,'No',NULL,NULL),(16,1,16,'No',NULL,NULL),(17,1,17,'No',NULL,NULL),(18,1,18,'Si',NULL,NULL),(19,1,19,'Si',NULL,NULL),(20,1,20,'Si',NULL,NULL),(21,1,21,'Si',NULL,NULL),(22,1,22,'Si',NULL,NULL),(23,1,23,'Si',NULL,NULL),(24,1,24,'Si',NULL,NULL),(25,1,25,'Si',NULL,NULL),(26,1,26,'Si',NULL,NULL),(27,1,27,'Si',NULL,NULL),(28,1,28,'Si',NULL,NULL),(29,1,29,'Si',NULL,NULL),(30,1,30,'Si',NULL,NULL),(31,1,31,'Si',NULL,NULL),(32,1,32,'Si',NULL,NULL),(33,1,33,'Si',NULL,NULL),(34,1,34,'Si',NULL,NULL),(35,1,35,'Si',NULL,NULL),(36,2,1,'Si',NULL,NULL),(37,2,2,'Si',NULL,NULL),(38,2,3,'Si',NULL,NULL),(39,2,4,'Si',NULL,NULL),(40,2,5,'Si',NULL,NULL),(41,2,6,'Si',NULL,NULL),(42,2,7,'Si',NULL,NULL),(43,2,8,'Si',NULL,NULL),(44,2,9,'Si',NULL,NULL),(45,2,10,'Si',NULL,NULL),(46,2,11,'No',NULL,NULL),(47,2,12,'No',NULL,NULL),(48,2,13,'No',NULL,NULL),(49,2,14,'No',NULL,NULL),(50,2,15,'No',NULL,NULL),(51,2,16,'No',NULL,NULL),(52,2,17,'Si',NULL,NULL),(53,2,18,'Si',NULL,NULL),(54,2,19,'Si',NULL,NULL),(55,2,20,'Si',NULL,NULL),(56,2,21,'Si',NULL,NULL),(57,2,22,'Si',NULL,NULL),(58,2,23,'Si',NULL,NULL),(59,2,24,'Si',NULL,NULL),(60,2,25,'Si',NULL,NULL),(61,2,26,'Si',NULL,NULL),(62,2,27,'Si',NULL,NULL),(63,2,28,'Si',NULL,NULL),(64,2,29,'Si',NULL,NULL),(65,2,30,'Si',NULL,NULL),(66,2,31,'Si',NULL,NULL),(67,2,32,'Si',NULL,NULL),(68,2,33,'Si',NULL,NULL),(69,2,34,'Si',NULL,NULL),(70,2,35,'Si',NULL,NULL),(71,3,1,'Si',NULL,NULL),(72,3,2,'Si',NULL,NULL),(73,3,3,'Si',NULL,NULL),(74,3,4,'Si',NULL,NULL),(75,3,5,'Si',NULL,NULL),(76,3,6,'Si',NULL,NULL),(77,3,7,'Si',NULL,NULL),(78,3,8,'Si',NULL,NULL),(79,3,9,'Si',NULL,NULL),(80,3,10,'Si',NULL,NULL),(81,3,11,'Si',NULL,NULL),(82,3,12,'Si',NULL,NULL),(83,3,13,'Si',NULL,NULL),(84,3,14,'Si',NULL,NULL),(85,3,15,'No',NULL,NULL),(86,3,16,'No',NULL,NULL),(87,3,17,'No',NULL,NULL),(88,3,18,'Si',NULL,NULL),(89,3,19,'Si',NULL,NULL),(90,3,20,'Si',NULL,NULL),(91,3,21,'Si',NULL,NULL),(92,3,22,'Si',NULL,NULL),(93,3,23,'Si',NULL,NULL),(94,3,24,'Si',NULL,NULL),(95,3,25,'Si',NULL,NULL),(96,3,26,'Si',NULL,NULL),(97,3,27,'Si',NULL,NULL),(98,3,28,'Si',NULL,NULL),(99,3,29,'Si',NULL,NULL),(100,3,30,'Si',NULL,NULL),(101,3,31,'Si',NULL,NULL),(102,3,32,'Si',NULL,NULL),(103,3,33,'Si',NULL,NULL),(104,3,34,'Si',NULL,NULL),(105,3,35,'Si',NULL,NULL),(106,4,1,'No',NULL,NULL),(107,4,2,'No',NULL,NULL),(108,4,3,'No',NULL,NULL),(109,4,4,'No',NULL,NULL),(110,4,5,'No',NULL,NULL),(111,4,6,'No',NULL,NULL),(112,4,7,'No',NULL,NULL),(113,4,8,'No',NULL,NULL),(114,4,9,'No',NULL,NULL),(115,4,10,'No',NULL,NULL),(116,4,11,'Si',NULL,NULL),(117,4,12,'Si',NULL,NULL),(118,4,13,'Si',NULL,NULL),(119,4,14,'Si',NULL,NULL),(120,4,15,'No',NULL,NULL),(121,4,16,'No',NULL,NULL),(122,4,17,'No',NULL,NULL),(123,4,18,'No',NULL,NULL),(124,4,19,'No',NULL,NULL),(125,4,20,'No',NULL,NULL),(126,4,21,'No',NULL,NULL),(127,4,22,'No',NULL,NULL),(128,4,23,'No',NULL,NULL),(129,4,24,'No',NULL,NULL),(130,4,25,'No',NULL,NULL),(131,4,26,'No',NULL,NULL),(132,4,27,'No',NULL,NULL),(133,4,28,'No',NULL,NULL),(134,4,29,'No',NULL,NULL),(135,4,30,'No',NULL,NULL),(136,4,31,'No',NULL,NULL),(137,4,32,'No',NULL,NULL),(138,4,33,'No',NULL,NULL),(139,4,34,'No',NULL,NULL),(140,4,35,'No',NULL,NULL),(141,5,1,'No',NULL,NULL),(142,5,2,'No',NULL,NULL),(143,5,3,'No',NULL,NULL),(144,5,4,'No',NULL,NULL),(145,5,5,'Si',NULL,NULL),(146,5,6,'Si',NULL,NULL),(147,5,7,'Si',NULL,NULL),(148,5,8,'No',NULL,NULL),(149,5,9,'No',NULL,NULL),(150,5,10,'No',NULL,NULL),(151,5,11,'No',NULL,NULL),(152,5,12,'No',NULL,NULL),(153,5,13,'No',NULL,NULL),(154,5,14,'No',NULL,NULL),(155,5,15,'No',NULL,NULL),(156,5,16,'No',NULL,NULL),(157,5,17,'No',NULL,NULL),(158,5,18,'No',NULL,NULL),(159,5,19,'No',NULL,NULL),(160,5,20,'Si',NULL,NULL),(161,5,21,'No',NULL,NULL),(162,5,22,'No',NULL,NULL),(163,5,23,'No',NULL,NULL),(164,5,24,'No',NULL,NULL),(165,5,25,'No',NULL,NULL),(166,5,26,'No',NULL,NULL),(167,5,27,'No',NULL,NULL),(168,5,28,'No',NULL,NULL),(169,5,29,'No',NULL,NULL),(170,5,30,'No',NULL,NULL),(171,5,31,'No',NULL,NULL),(172,5,32,'No',NULL,NULL),(173,5,33,'No',NULL,NULL),(174,5,34,'No',NULL,NULL),(175,5,35,'No',NULL,NULL),(176,6,1,'Si',NULL,NULL),(177,6,2,'Si',NULL,NULL),(178,6,3,'Si',NULL,NULL),(179,6,4,'Si',NULL,NULL),(180,6,5,'Si',NULL,NULL),(181,6,6,'Si',NULL,NULL),(182,6,7,'Si',NULL,NULL),(183,6,8,'Si',NULL,NULL),(184,6,9,'Si',NULL,NULL),(185,6,10,'Si',NULL,NULL),(186,6,11,'Si',NULL,NULL),(187,6,12,'Si',NULL,NULL),(188,6,13,'Si',NULL,NULL),(189,6,14,'Si',NULL,NULL),(190,6,15,'Si',NULL,NULL),(191,6,16,'Si',NULL,NULL),(192,6,17,'Si',NULL,NULL),(193,6,18,'Si',NULL,NULL),(194,6,19,'Si',NULL,NULL),(195,6,20,'Si',NULL,NULL),(196,6,21,'Si',NULL,NULL),(197,6,22,'Si',NULL,NULL),(198,6,23,'Si',NULL,NULL),(199,6,24,'Si',NULL,NULL),(200,6,25,'Si',NULL,NULL),(201,6,26,'Si',NULL,NULL),(202,6,27,'Si',NULL,NULL),(203,6,28,'Si',NULL,NULL),(204,6,29,'Si',NULL,NULL),(205,6,30,'Si',NULL,NULL),(206,6,31,'Si',NULL,NULL),(207,6,32,'Si',NULL,NULL),(208,6,33,'Si',NULL,NULL),(209,6,34,'Si',NULL,NULL),(210,6,35,'Si',NULL,NULL);
/*!40000 ALTER TABLE `usuarios_has_privilegios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

